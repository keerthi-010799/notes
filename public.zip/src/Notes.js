import React, { Component, createRef } from "react";
import "./Notes.css";
import Individualnote from "./components/Individualnote/Individualnote";
import TextareaAutoresize from "react-autosize-textarea";
import Sidedrawer from "./components/sidedrawer/sidedrawer";
import person from "./assets/images/icons/person.svg";
import palette from "./assets/images/icons/palette.svg";
import image from "./assets/images/icons/image.svg";
import others from "./assets/images/icons/others.svg";
import archive from "./assets/images/icons/archive.svg";
import check from "./assets/images/icons/check.svg";
import brush from "./assets/images/icons/brush.svg";
import pin from "./assets/images/icons/pin.svg";
import Modal from ".//components/Modal/Modal";
import tick from  "./assets/images/icons/tick.svg"
import Tooltip from "react-tooltip";
import Listednotes from "./components/Listednotes/Listednotes";

class Notes extends Component {
  constructor(props) {
    super(props);
    this.addingRef = React.createRef();
  }
  state = {
    modal: {
      status: false,
      noteIndex: null,
    },
    notes:[],
    currentNote: {
      type:"normal",
      title: "",
      note: "",
      list:""
    },
  };
  componentDidMount() {
    document.addEventListener("mousedown", this.ChangeHandler);
  }
  componentWillUnmount() {
    document.removeEventListener("mousedown", this.ChangeHandler);
  }
  checklistHandler=()=>{
    this.setState({currentNote:{type:"list"}})
  }
  ChangeHandler = (event) => {
    if (this.addingRef && !this.addingRef.current.contains(event.target)) {
      if (this.state.currentNote.note||this.state.currentNote.list) {
        const notes = [...this.state.notes];
        notes.push({...this.state.currentNote});
        this.setState({
          notes,
          currentNote: {
            type:"normal",
            title: "",
            note:"",
            list:""
          }
        });
  }
 }
};
  handleInput = (e) => {
    this.setState({
      currentNote: {
        ...this.state.currentNote,
        [e.target.name]: e.target.value,
      },
    });
  };
toggleModal = (status, noteIndex) => {
    this.setState({ modal: { status, noteIndex }});
};
  modalChangeHandler = ({ title, note, list }) => {
    const notes = [...this.state.notes];
    notes[this.state.modal.noteIndex] = { title, note, list };
    this.setState({ notes });
  };
  titleChangeHandler = (event) => {
  const title = event.target.value;
  this.modalChangeHandler({ title: title });
  };
  render() {
    const { currentNote } = this.state;
    const lists = this.state.notes.map((note, noteIndex) => {  
      return (
        <div className="dummy">
               <div className="notetickicon">
              <img src={tick} alt=" " />
          </div>
          <div
            style={{backgroundColor:this.state.colors}}
            className="d-flex flex-column bd-highlight note">
            <div style={{ display: "flex" }} >
              <input
                autoComplete="off"
                style={{backgroundColor:this.state.colors}}
                value={note.title} 
                className="noteitemtitle"
                placeholder="Title"
                onBlur={this.modalChangeHandler}
                onChange={this.titleChangeHandler}
                />
              <div>
              <div className="noteiconpinimage">
                <img src={pin} alt=" " />
              </div>
            </div>
            </div>  
            {this.state.notes[noteIndex].type === "list" ? 
            <Listednotes 
            style={{marginLeft:"20px"}}
             inputshow={{display:"none"}}
             clicked={()=>this.toggleModal(true,noteIndex)}
             list={note.list}  
            // enternotes={this.enterHandler} 
             />
                :
                 <Individualnote 
                  clicked={()=>this.toggleModal(true,noteIndex)}
                  note={note.note}/>
               }
              <div className="notetitle" style={{display:"flex"}}>
              <div className="notebellicon">
                <img
                  src="https://cdn2.iconfinder.com/data/icons/ui-essential-10/24/add_reminder-512.png"
                  height="25px"
                  width="25px"
                  alt=""
                  data-tip data-for="remainder"
                />
                <Tooltip id="remainder" place="bottom">Remainder</Tooltip>
              </div>
              <div className="noteicon">
                <img src={person} alt="" data-tip data-for="person"/>
                <Tooltip id="person" place="bottom">Collabarator</Tooltip>
              </div>
              <div className="noteicon">
                <img src={palette} alt="" data-tip data-for="palette" onClick={this.palatteClickHandler}/>
                <Tooltip id="palette" place="bottom">Change color</Tooltip>
              </div>
              <div className="noteicon">
                <img src={image} alt="" data-tip data-for="image"/>
                <Tooltip id="image" place="bottom">Add image</Tooltip>
              </div>
              <div className="noteicon">
                <img src={archive} alt="" data-tip data-for="archive"/>
                <Tooltip id="archive" place="bottom">Archive</Tooltip>
              </div>
              <div className="noteicon">
                <img
                 src={others} alt="" data-tip data-for="other"/>
                <Tooltip id="other" place="bottom">More</Tooltip>
              </div>
              </div>
            </div>
        </div>
      );
    });
    return (
      <div className="overAllContainer">
        <div>
          <Sidedrawer/>
        </div>
        <div className="notecontainer">
          <div className="addnote row align-item-center" ref={this.addingRef}>
            <div className="notetitle">
              <input 
                autoComplete="off"
                className="noteinput"
                placeholder="Title"
                value={currentNote.title}
                name={"title"}
                onChange={this.handleInput}
              />
              <div style={{ marginLeft: "240px" }} className="noteicon">
                <img src={pin} alt="" />
              </div>
            </div>
            <div
              style={{
                width: "100%",
                display: "flex",
                paddingTop: "2px",
                paddingBottom: "2px",
                paddingLeft: "10px",}}>
              {this.state.currentNote.type !== "list" ?
              <TextareaAutoresize
                className="addingtext"
                placeholder="Take a note..."
                value={currentNote.note}
                name={"note"}
                onChange={this.handleInput}
              />:<div style={{position:"relative"}}>
              <input
              autoComplete="off"
              style={{marginLeft:"20px"}}
              className = "addinglisttext"
              placeholder = "+  List item"
              value={currentNote.list}
              name={"list"}
              onChange={this.handleInput}
              /></div>} 
              <div 
                className="texticon"
                style={{ marginLeft: "30px" }}
                onClick={this.checklistHandler}>
                <img src={check} alt="" data-tip data-for="tick"/>
                <Tooltip id="tick" place="bottom">New List</Tooltip>
              </div>
              <div className="texticon" style={{ marginLeft: "20px" }}>
                <img src={brush} alt="" data-tip data-for="brush"/>
                <Tooltip id="brush" place="bottom">Insert drawing</Tooltip>
              </div>
              <div
                className="texticon"
                style={{ marginLeft: "20px", marginRight: "1px" }}>
                <img src={image} alt="" data-tip data-for="image"/>
                <Tooltip id="image" place="bottom">Insert image</Tooltip>
              </div>
            </div>
            <div className="iconlist">
              <div className="notebellicon">
                <img
                  src="https://cdn2.iconfinder.com/data/icons/ui-essential-10/24/add_reminder-512.png"
                  height="25px"
                  width="25px"
                  alt=""
                  data-tip data-for="remainder"
                  />
                  <Tooltip id="remainder" place="bottom">Remainder</Tooltip>
                </div>
                <div className="noteicon">
                  <img src={person} alt="" data-tip data-for="person"/>
                  <Tooltip id="person" place="bottom">Collabarator</Tooltip>
                </div>
                <div className="noteicon">
                 <img src={palette} alt="" data-tip data-for="palette" />
                  <Tooltip id="palette" place="bottom">Change color</Tooltip>
                </div>
                <div className="noteicon">
                  <img src={image} alt="" data-tip data-for="image"/>
                  <Tooltip id="image" place="bottom">Add image</Tooltip>
                </div>
                <div className="noteicon">
                  <img src={archive} alt="" data-tip data-for="archive"/>
                  <Tooltip id="archive" place="bottom">Archive</Tooltip>
                </div>
                <div className="noteicon">
                  <img src={others} alt="" data-tip data-for="other"/>
                  <Tooltip id="other" place="bottom">More</Tooltip>
                </div>
              <div className="closing">close</div>
            </div>
          </div>
          <div className="container">
           
            <div className="d-flex flex-wrap">{lists}</div>
          
            {this.state.modal.status ? (
              <Modal clicked={() => this.toggleModal(false, null)}>
                {this.state.modal.noteIndex !== null && (
                  <div
                    style={{backgroundColor:this.state.colors}}
                    className="d-flex flex-column bd-highlight mb-3 modalinner"
                    onClick={(e) => {
                      e.stopPropagation();
                    }}
                    >
                    {" "} 
                    {<ul style={{paddingLeft:"2px",backgroundColor:"white"}}>
                   <div style={{ display: "flex" }} >
                     <input
                        autoComplete="off"
                        style={{backgroundColor:this.state.colors}}
                    l   value={this.state.notes[this.state.modal.noteIndex].title}
                       className="noteitemtitle"
                       placeholder="Title"
                       onBlur={this.titlechanged}
                       onChange={this.titleChangeHandler}
                       />
                     <div>
                     <div className="noteiconpinimage" style={{visibility:"visible"}}>
                       <img src={pin} alt=" " />
                     </div>
                 </div>
                   </div> 
                      {this.state.notes[this.state.modal.noteIndex].type ==="list" ? 
                          <Listednotes //notechanged={this.modalChangeHandler}
                          list={this.state.notes[this.state.modal.noteIndex].list}
                          notechanged={this.modalChangeHandler}
                          //listarr={this.arrhandler.bind(this)} 
                          />
                           :
                          <Individualnote 
                          notechanged={this.modalChangeHandler}
                          note={this.state.notes[this.state.modal.noteIndex].note}/>
                      }
                <div className="notetitle" style={{display:"flex"}}>
                <div className="modalnotebellicon">
                <img
                  src="https://cdn2.iconfinder.com/data/icons/ui-essential-10/24/add_reminder-512.png"
                  height="25px"
                  width="25px"
                  alt=""
                  data-tip data-for="remainder"
                  />
                  <Tooltip id="remainder" place="bottom">Remainder</Tooltip>
                </div>
                <div className="modalnoteicon">
                  <img src={person} alt="" data-tip data-for="person"/>
                  <Tooltip id="person" place="bottom">Collabarator</Tooltip>
                </div>
                <div className="modalnoteicon" onClick={this.palatteClickHandler}>
                  <img src={palette} alt="" data-tip data-for="palette"/>
                  <Tooltip id="palette" place="bottom">Change color</Tooltip>
                </div>
                <div className="modalnoteicon">
                  <img src={image} alt="" data-tip data-for="image"/>
                  <Tooltip id="image" place="bottom">Add image</Tooltip>
                </div>
                <div className="modalnoteicon">
                  <img src={archive} alt="" data-tip data-for="archive"/>
                  <Tooltip id="archive" place="bottom">Archive</Tooltip>
                </div>
                <div className="modalnoteicon">
                  <img src={others} alt="" data-tip data-for="other"/>
                  <Tooltip id="other" place="bottom">More</Tooltip>
                </div>
                </div>
                    </ul>}
                  </div>
                )}
              </Modal>
            ) : null}
          </div>
        </div>
      </div>
    );
  }
}
export default Notes;