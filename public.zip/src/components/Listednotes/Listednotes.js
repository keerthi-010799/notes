import React,{Component} from "react";
import TextareaAutoresize from "react-autosize-textarea";

class Listednotes extends Component {
  state={
    listed:[],
    currentlist:{list:" "},
    modal:{index:""}
  }
 noteChangeHandler = (event) => {
    const list = event.target.value;
    this.props.notechanged({title:this.props.title,note:this.props.note,list: list});
  };  
  enterHandler = (e) => {
    if (e.key === "Enter") {
        const listed = [...this.state.listed];
        listed.push({ ...this.state.currentlist});
        this.setState({
          listed,
          currentlist: {
            list:" "
          },
        });
      }
  };
  listmodalChangeHandler = ({ list }) => {
    const listed = [...this.state.listed];
    listed[this.state.modal.index] = { list };
    this.setState({ listed });
  };
  handlelistedinput = (e) => {
    this.setState({
      currentlist: {
        ...this.state.currentlist,
        [e.target.name]: e.target.value,
      },
    });
  };
  render(){
    const {currentlist} = this.state;  
    const tickes = this.state.listed.map((list,index)=>{
      return(
        <div style={{position:"relative"}}>
        <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSIjMDAwIj4KICA8cGF0aCBkPSJNMTkgNXYxNEg1VjVoMTRtMC0ySDVjLTEuMSAwLTIgLjktMiAydjE0YzAgMS4xLjkgMiAyIDJoMTRjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnoiLz4KPC9zdmc+Cg=="
        alt="" style={{position:"absolute",marginTop:"17px",marginLeft:"17px"}}
        height="16"   width="16" />
            <TextareaAutoresize 
                style={{marginLeft:"20px"}}
                className="textnotes"
                value={list.list}
                //onclick={()=>this.listing(index)}
                //onChange={this.listchangeHandler}
                /> 
        </div>
      )
    })
  return (
      <div>
    <div style={{position:"relative"}}>
      <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSIjMDAwIj4KICA8cGF0aCBkPSJNMTkgNXYxNEg1VjVoMTRtMC0ySDVjLTEuMSAwLTIgLjktMiAydjE0YzAgMS4xLjkgMiAyIDJoMTRjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnoiLz4KPC9zdmc+Cg=="
      alt="" style={{position:"absolute",marginTop:"17px",marginLeft:"17px"}}
      height="16"   width="16" />
            <TextareaAutoresize 
            onClick={this.props.clicked}
             style={{marginLeft:"20px"}}
             className="textnotes"
             value={this.props.list}
             name={"list"}
             onChange={this.noteChangeHandler}
            /> </div>
            <div>{tickes}</div>
              <input
              autoComplete="off" 
              placeholder ="+ list item"
              //style={this.props.inputshow}
              className ="listinput" 
              name={"list"} 
              //onclick={this.props.listarr(this.state.listed.list)}
              value={currentlist.list} 
              onChange={this.handlelistedinput} 
              onKeyPress={this.enterHandler}
              />
              </div>
    )}
  }
export default Listednotes; 