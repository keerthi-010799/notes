    const tickedlist = this.state.listedNotes.map((listedNote,listedIndex)=>{
      return (<div style={{position:"relative"}}>
      <div className="listtextbox" onClick={()=>this.checkedHandler(listedIndex)}>
        <img src="data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSIjMDAwIj4KICA8cGF0aCBkPSJNMTkgNXYxNEg1VjVoMTRtMC0ySDVjLTEuMSAwLTIgLjktMiAydjE0YzAgMS4xLjkgMiAyIDJoMTRjMS4xIDAgMi0uOSAyLTJWNWMwLTEuMS0uOS0yLTItMnoiLz4KPC9zdmc+Cg=="
         alt="" 
         height="16" 
         width="16" />
      </div>
      <TextareaAutoresize
      style={{marginLeft:"20px"}}
       onClick={()=>this.toggleModal(true,listedIndex)}
       className="textnotes"
       value={listedNote.note}
       name={"note"}
       onChange={this.noteChangeHandler}
     /></div>)
    }